<li><a href="{{ route('intellisas.home') }}" class="ai-icon" aria-expanded="false">
    <i class="flaticon-013-checkmark"></i>
    <span class="nav-text">Home</span>
</a>
</li>

<li><a href="{{ route('schools.index') }}" class="ai-icon" aria-expanded="false">
    <i class="flaticon-013-checkmark"></i>
    <span class="nav-text">Schools</span>
</a>
</li>

