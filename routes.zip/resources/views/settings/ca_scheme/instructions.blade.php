<div class="modal fade instructions" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Instructions</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal">
                </button>
            </div>
            <div class="modal-body">
                <ul class="list-icons">
                    <li><span class="align-middle me-2"><i class="ti-angle-right"></i></span> Here you can add your school's Continous Assement Scheme. Teachers can allocate marks to each of the CA Category</li>
                    <li><span class="align-middle me-2"><i class="ti-angle-right"></i></span> Skipping marking a particular CA will not cause error in reult generation</li>
                    <li><span class="align-middle me-2"><i class="ti-angle-right"></i></span> Total marks for CA must be 40%. as exams is 60%.</li>
                    <li><span class="align-middle me-2"><i class="ti-angle-right"></i></span> Your CA can take this format: Code = CA1, Description = First CA Test, Marks Percentage = 10.</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger light" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>